/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projetgestion.financiere;

/**
 *
 * @author HP
 */
public class ProjetgestionFinanciere {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
